package com.msotor.firebase01.modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class Usuario {

    private String userId;
    private String nomUsurio;
    private String eMail;
    private Date fechaIngreso;
    private String contrasena;

    public Usuario(){}
     public Usuario(String userId, String nomUsurio, String eMail, Date fechaIngreso, String contrasena) {
        this.nomUsurio = nomUsurio;
        this.eMail = eMail;
        this.fechaIngreso = fechaIngreso;
        this.contrasena = contrasena;
        this.userId = userId;
    }

    public String getNomUsurio() {
        return nomUsurio;
    }

    public void setNomUsurio(String nomUsurio) {
        this.nomUsurio = nomUsurio;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
